/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Car;

/**
 *
 * @author lfv5020
 */
public class addGas {
/*    
    protected double addGas;
    protected double fuelLevel;
    
    public void setaddGas(double g){
    addGas = g;
        
    } 
    
    public double addGas(){
    return fuelLevel;  
    }
    
    
    public double addGas(){
    
        fuelLevel += addGas;
        return fuelLevel;
    
    }
  */
        double fuel;
    
        void tank(double extraFuel) {

        fuel += extraFuel; 

    }
    
}


  /*
        getGasLevel g1 = new getGasLevel();
        addGas g2 = new addGas();
        drive d1 = new drive();
        */