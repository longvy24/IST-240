/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Car;

/**
 *
 * @author lfv5020
 */
public class getGasLevel{
       
    /*
    protected double fuelLevel; //Amount of fuel put into gas tank
   
    public void setgetGasLevel(double f){
    fuelLevel = f;
    }
    
    public double getGasLevel(){
    return fuelLevel;
    }
    */
    
    double fuel;
     
    double getFuelLevel() {

    return fuel; 

    }   

}
